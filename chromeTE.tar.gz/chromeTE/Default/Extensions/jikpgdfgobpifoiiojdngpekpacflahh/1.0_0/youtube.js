var newtab = this.window;

window.addEventListener('load', function(){
	newtab = window.open();
    newtab.focus();
}, false);

window.addEventListener('pagehide', function(){
    newtab.close();
}, false);