document.onreadystatechange = function() {
    if (document.readyState == "complete") {
        document.querySelector('textarea').value="https://www.youtube.com/watch?v=0T_hIB-viJ0&list=PLNFHZ147pUItjKgODlwExeXrfRkHsk4uH&shuffle=1"
        document.querySelector('select#country').value="western"
        document.querySelector('select#district').value="1"
        document.querySelector('select#agent').value="1"
    }
}