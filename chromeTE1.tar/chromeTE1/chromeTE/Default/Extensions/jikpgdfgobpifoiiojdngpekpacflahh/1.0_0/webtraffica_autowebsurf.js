document.onreadystatechange = function() {
    if (document.readyState == "complete") {
        document.getElementById('code-block').addEventListener('click',function () {
    alert('button click!');
});
    }
}