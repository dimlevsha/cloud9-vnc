document.onreadystatechange = function() {
    if (document.readyState == "complete") {
    	$('.titre_12 a[target=_blank]')[0].click()
        // document.getElementsByClassName('titre_12')[1].getElementsByTagName('a')[0].click()
    }
}
