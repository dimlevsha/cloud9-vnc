document.onreadystatechange = function() {
    if (document.readyState == "complete") {
        if (window.location.href.indexOf("vidoza.net/hyj07103ylz8.html") > -1 || window.location.href.indexOf("vidoza.net/hyj07103ylz8.html") > -1) {
            function sex() {
				var centerX = document.documentElement.clientWidth / 2;
var centerY = document.documentElement.clientHeight / 2;
                $(document.elementFromPoint(centerX, centerY)).click();
				 
            }
setInterval(sex, 3000); 
        }
        
    }
}